'use strict'

//module.exports = (val) => 'XXX'
module.exports = (val) => process.env[val]
