'use strict'

module.exports = (val) => process.env[val]
